const express = require("express");
const { create, signIn, verifyEmail, resendEmailVerificatioToken, forgetPassword, sendResetPasswordTokenStatus, resetPassword} = require("../controller/user.js");
const { userValidtor, signInValidator, validate, validatePassword } = require("../middlewares/validator.js");
const { isValidPassResetToken } = require("../middlewares/user.js");
const { errorHandler } = require("../middlewares/error.js");


const router = express.Router();

router.post("/create",userValidtor,validate, create);
router.post("/sign-in",signInValidator, validate, signIn,errorHandler);

router.post("/verify-email",verifyEmail );
router.post("/resend-email-verification-token",resendEmailVerificatioToken );
router.post("/forget-password",forgetPassword );
router.post("/verify-pass-reset-token",isValidPassResetToken, sendResetPasswordTokenStatus);
router.post("/reset-password", isValidPassResetToken, resetPassword, validatePassword, validate);

module.exports = router; 