export const commonModalClasses =
  "dark:bg-secondary bg-white drop-shadow-lg rounded p-6 space-y-6";
